package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int i ,n, item ,c=0 , mid=0;
        int[] a;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter how many elements you want to insert");
        n=sc.nextInt();

        a = new int[n];

        System.out.println("ENTER ELEMENTS");
        for (i =0 ; i<n ; i++)
        {
            a[i]=sc.nextInt();
        }
        System.out.println("Enter the element want to find");
        item= sc.nextInt();
        int beg=0 , end=n-1;

        while (beg<=end)
        {
             mid = (beg+end)/2;
            if (item==a[mid])
            {
                c++;
                break;
            }
            else if (item>a[mid])
            {
                beg=mid+1;
            }
            else if (item<a[mid])
            {
                end=mid-1;
            }

        }

        if (c>0)
        {
            System.out.println("item found at " + mid);
        }
        else {
            System.out.println("item not found at " + mid);
        }

    }
}
