package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int i ,n, item;
        int[] a;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter how many elements you want to insert");
        n=sc.nextInt();

        a = new int[n];

        System.out.println("ENTER ELEMENTS");
        for (i =0 ; i<n ; i++)
        {
             a[i]=sc.nextInt();
        }
        System.out.println("Enter the element want to find");
        item= sc.nextInt();
            int c = 0;
        for (i=0 ; i<a.length ; i++)
        {
            if (a[i]==item)
            {
                c++;
                break;
            }

        }

        if (c>0)
        {
            System.out.println("item exist at "+ i);
        }
        else {
            System.out.println("item does not exist");
        }

    }
}
