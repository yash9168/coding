package com.company;

import jdk.swing.interop.SwingInterOpUtils;

import java.util.Scanner;

public class hacekrankpractice {
    public static void main(String[] args) {



          Scanner sc = new Scanner(System.in);

      int n = sc.nextInt();
     String s = Integer.toString(n);
            if (n==Integer.parseInt(s)){
                System.out.println("Good job");

            }
            else{
                System.out.println("Wrong answer");
            }
    }
}
