package com.company;

public class PrecnAcc {
    public static void main(String[] args) {
        int x =2;
        int y=4;
        float z = 2/4-2f*4;
        System.out.println(z);
    }
}
