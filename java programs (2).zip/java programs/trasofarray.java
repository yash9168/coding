package com.company;

public class trasofarray {
    public static void main(String[] args) {
        int[] marks = {2, 4, 5, 6,87,9};
        System.out.println(marks.length);


//        for (int i=0 ; i<marks.length ; i++)
//        {
//            System.out.println(marks[i]);
//        }



        for (int i = marks.length-1;  i>=0 ; i--)
        {
            System.out.println(marks[i]);
        }

    }
}