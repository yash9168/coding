package com.company;

public class Operators {
    public static void main(String[] args) {
        int a =4;
        int b =8 % a;
        System.out.println(b);
        System.out.println(4==5);
        int c=3;
        c +=2;
        System.out.println(c);
        System.out.println(32>2 && 32>3);
        System.out.println(32>2 || 32<4);
    }
}
