package com.company;

class Cylinder{
    private int r;
    private int h;

    public int getR() {
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }

    public int getH() {
        return h;
    }

    public void setH(int h) {
        this.h = h;
    }


    public  double surfacearea(){
        return 2*3.14*r*h;
    }

    public  Cylinder(int radious , int height){
        int r  =radious;
        int h = height;

    }


}





public class practicesetconstructor {
    public static void main(String[] args) {


        Cylinder cy = new Cylinder(54,54);

        cy.setH(7);
        cy.setR(14);

        System.out.println(cy.getH());
        System.out.println(cy.getR());

        System.out.println(cy.surfacearea());
//    }


}}
