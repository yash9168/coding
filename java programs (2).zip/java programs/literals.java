package com.company;

public class literals {
    public static void main(String[] args) {
        int age = 32;
        System.out.println(age);
        char S = 'a';
        System.out.println(S);
        float a = 6.6f;
        System.out.println(a);
        double B = 4.342d;
        System.out.println(B);
        String w = "yash";
        System.out.println(w);
    }
}
