package com.company;

public class practiceset3 {
    public static void main(String[] args) {
//        String Name = "YASH SHAH";
//        System.out.println(Name.toLowerCase());


//        String Name = "YASH SHAH";
//        System.out.println(Name.replace(' ' , '_'));


//            String Name = " YASH     SHAH";
//        System.out.println(Name.indexOf("  "));




        String Name  =   " YASH SHAH IS A GOOD BOY \n THANK YOU";
        System.out.println(Name);


    }
}
