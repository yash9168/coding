package com.company;

public class Conditional {
    public static void main(String[] args) {
        int age = 2;
        if (age>18)
        {
            System.out.println("YESS U CAN DRIVE");
        }
        else {
            System.out.println("U CANNOT DRIVE");
        }
    }
}
