package com.company;

class  Mythread extends Thread{
    @Override  public void run(){
        int i = 0;
        while (i<20){
            System.out.println("i m tread 1");
            i++;
        }
    }
}

class Mythread2 extends Thread{
   @Override public  void run(){
       int i = 0;
        while (i<20){
            System.out.println("im trread 2");
            i++;
        }
    }
}


public class multithreading {
    public static void main(String[] args) {
        Mythread m1 = new Mythread();
        Mythread2 m2 = new Mythread2();

        m1.start();
        m2.start();
    }
}
