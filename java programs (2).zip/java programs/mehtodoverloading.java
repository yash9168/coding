package com.company;

public class mehtodoverloading {

    static  void telljoke(){
        System.out.println("I m yash");
    }

    static void change(int arr[]){
        arr[1] = 7;
    }



    public static void main(String[] args) {

//        telljoke();

        int arr [] = {1,2,3,4,5};
        change(arr);
        System.out.println(arr[1]);

    }
}
