package com.company;

import java.time.Year;

public class StringMehtods {
    public static void main(String[] args) {
         String name = "YASHSHAHA";
        System.out.println(name.length());
        System.out.println(name.toLowerCase());
        System.out.println(name.trim());
        System.out.println(name.replace('Y' , 'J')
        );
    }
}
