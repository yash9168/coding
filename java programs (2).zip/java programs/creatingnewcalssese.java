package com.company;


class Employee
{
    public int salary;
    int id;
    String name;
    public void preintgetdetails(){
        System.out.println(id);
        System.out.println(name);
    }

    public int getsalary(){
        return salary;
    }
}

public class creatingnewcalssese {
    public static void main(String[] args) {

        Employee yash = new Employee();
        yash.id=12;
        yash.name = "yuvi";

        yash.salary=49;
        yash.preintgetdetails();

        int salary = yash.getsalary();
        System.out.println(salary);


    }
}
