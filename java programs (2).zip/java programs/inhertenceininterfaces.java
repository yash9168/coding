package com.company;

interface Sample{
    void meht1();
    void meht2();
}

interface childinterface extends Sample{
    void meht3();
    void meht4();
}

class Mysampleclass implements childinterface{
    @Override
    public void meht3() {
        System.out.println("meht3");
    }

    @Override
    public void meht4() {
        System.out.println("meht4");
    }

    @Override
    public void meht1() {
        System.out.println("meht1");
    }

    @Override
    public void meht2() {
        System.out.println("meht2");
    }
}


public class inhertenceininterfaces {
    public static void main(String[] args) {

        Mysampleclass m =new Mysampleclass();
        m.meht1();
        m.meht2();
        m.meht3();
        m.meht4();

    }
}
