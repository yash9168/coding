package com.company;

public class Main {

    public static void main(String[] args) {
        int a = 2;
        int b= 3;
        int c = 5;
        int sum = a+b+c;

        System.out.println("the sum of no is " + sum);
    }
}
