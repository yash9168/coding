package com.company;

import java.util.Scanner;

public class hackerramkalgopractice {
    public static void main(String[] args) {


        Scanner sc = new Scanner(System.in);

        String name = sc.nextLine();

        System.out.println("Hello, World.");



        System.out.println(name);


    }


    }

