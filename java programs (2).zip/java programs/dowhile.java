package com.company;

public class dowhile {
    public static void main(String[] args) {
        int n=0;
        do {
            System.out.println(n);
            n++;
        }while (n>0);
    }
}
