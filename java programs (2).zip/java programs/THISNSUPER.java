package com.company;

class Ekclass{
    int a;

    public int getA() {
        return a;
    }

    Ekclass(int a){
        this.a =a;
    }
}



public class THISNSUPER {


    public static void main(String[] args) {
        Ekclass E =new Ekclass(43);
        System.out.println(E.getA());

    }
}
