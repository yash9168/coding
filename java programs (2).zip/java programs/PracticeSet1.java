package com.company;

import java.util.Scanner;

public class PracticeSet1 {
    public static void main(String[] args) {
//        int a = 1;
//        int b=2;
//        int c=3;
//        int sum = a+b+c;
//
//        System.out.println("the sum of the no is " +  sum);

//        float sub1 = 34;
//        float sub2 = 45;
//        float sub3= 32;
//
//        float CGPA = (sub1+sub2+sub3)/30;
//        System.out.println("CGPA IS  "   + CGPA);


//        System.out.println("PLEASE ENTER UR NAME");
//        Scanner sc = new Scanner(System.in);
//        String Name = sc.next();
//        System.out.println("HELLO "  +  Name  +  " HAVE A GOOD DAY");

//
//                Scanner sc = new Scanner(System.in);
//        System.out.println("Please ENTER THE VALUE");
//
//        float a = sc.nextFloat();
//        System.out.println( "you ENTERED " + a +"km");
//           float b = a*1000;
//        System.out.println("after converting we get" +b);


        Scanner sc = new Scanner(System.in);
        System.out.println("PLEASE EENTERED THE INTEGER");

        System.out.println(sc.hasNextInt());





    }
}
