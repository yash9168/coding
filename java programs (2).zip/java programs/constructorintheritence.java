package com.company;


class Basw{
    int x ;

    Basw(){
        System.out.println("im construc1");
    }

    Basw(int a){
        System.out.println("im new constru " + a);
    }


    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }


}

class Derived extends Basw{
    int y;

             Derived(){
                 super(0);
                 System.out.println("im constructor2");
             }
    Derived(int a , int b){
        super(0);
        System.out.println("im constructor2 "+ a           + b);
    }


    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}


public class constructorintheritence {


    public static void main(String[] args) {

//        Basw b = new Basw();
        Derived d = new Derived(5,4);




    }
}
