package com.company;

public class mehtods {



    static int logic(int x  , int y) {
        int z;
        if (x > y) {

             z = x + y;

        } else {

            z = x - y;

        }


        return z;
    }


    public static void main(String[] args) {



        int a = 3;
        int b=4;
        int c;

        c = logic(a,b);

        int a1 = 4;
        int b1=3;
        int c1;

        c1 = logic(a1,b1);
        System.out.println(c);
        System.out.println(c1);
    }
}
