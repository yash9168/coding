package com.company;

public class forloop {
    public static void main(String[] args) {
//        for (int i=1 ; i<10 ; i++){
//            System.out.println(i);

//        int n =10;
//        for (int i =0 ; i<n; i++){
//            System.out.println(2*i+1);

        int n=0;
        for (int i =11 ; i>n ; i--)
        {
            System.out.println(i);


        }
    }
}
