package com.company;

import java.util.Scanner;

public class Strings {
    public static void main(String[] args) {
//        String Name = new String("YASH");
//        System.out.println(Name);

        Scanner sc = new Scanner(System.in);
        String yash = sc.nextLine();
        System.out.println(yash);


    }
}
