package com.company;

class Mythr extends Thread{
    public  Mythr(String name){
        super(name);
    }
//    public  void run() {
//        int i =15;
////        while (true) {
////            System.out.println("i im  thrread");
////        }
//    }
}


public class threadconstructor {
    public static void main(String[] args) {
Mythr m1 = new Mythr("YAsh");
m1.start();
m1.getName();
    }
}
