package com.company;



class mythr1 extends Thread{

    public void run(){
        int i =3;
        System.out.println("hello");
    }
}
class mythr2 extends Thread{

    public void run(){
        int i =3;
        System.out.println("hell2222o");
    }
}

public class THReadmehtods {
    public static void main(String[] args) {


        mythr1 m1 = new mythr1();
        mythr2 m2 = new mythr2();
        m1.start();
        try {
                        m1.join();
        }
        catch (Exception e ){
            System.out.println(e);
        }

        m2.start();
    }
}
