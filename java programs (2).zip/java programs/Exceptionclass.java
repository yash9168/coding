package com.company;

import java.util.Scanner;

class Myexception extends Exception{
    @Override
    public String getMessage() {
        return super.getMessage()   + "i m 2 message ";
    }

    @Override
    public String toString() {
        return toString() + "im 2 sting";
    }
}


public class Exceptionclass {
    public static void main(String[] args) {


        Scanner sc  =new Scanner(System.in);
        int a ;
        a = sc.nextInt();
        if (a<99){
            try {
                throw new Myexception();
            }catch (Exception e ){
                System.out.println(e.getMessage());
        }

    }
}}
