package com.company;

public class incrementndecrement {
    public static void main(String[] args) {
        int i =2;
        System.out.println(i++);
        System.out.println(i);
        System.out.println(++i);
        System.out.println(i);
    }
}
