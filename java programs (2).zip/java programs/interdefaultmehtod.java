package com.company;


import org.w3c.dom.ls.LSOutput;

interface Camera{
    void takesnap();
    void Recordvideo();
    default  void record4kvideo(){
        System.out.println("RECORDING 4k video");
    }
}
interface wifi{
    String[] getnetworks();
    void connectingnetwork();
}

class cellphone{
    void callnumer(int phoneno){
        System.out.println( "calling0" + phoneno);
    }
    void pickno(){
        System.out.println("CONNECTING");
    }
}

class Mysmartphone extends cellphone implements wifi ,Camera{
     public void takesnap(){
         System.out.println("taking picture");
    }

    public  void Recordvideo(){
        System.out.println("RECORDING");
    }
    public  String [] getnetworks(){
        System.out.println("list of connections");
        String [] networklost =  {
                "yash" , "airtel " , "idea"
        };
        return networklost;

    }

    @Override
    public void connectingnetwork() {
        System.out.println("connecting to " );
    }






}

public class interdefaultmehtod {
    public static void main(String[] args) {

        Mysmartphone oneplus = new Mysmartphone();
        String [] arr = oneplus.getnetworks();
        for (String item : arr){
            System.out.println(item);
        }


    }
}
