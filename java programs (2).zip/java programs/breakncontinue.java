package com.company;

public class breakncontinue {
    public static void main(String[] args) {
//        int i;
//        for (i=0 ; i<5 ; i++){
//            System.out.println(i);
//            if (i==2){
//                System.out.println("ENDS HERE");
//                    break;



                    int i;
                    for (i=0 ; i<5 ; i++)
                    {
                        if (i==2)
                        {
                            System.out.println("ignore");
                            continue;

            }
                        System.out.println(i);

        }

    }
}
