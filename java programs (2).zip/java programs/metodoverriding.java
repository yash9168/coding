package com.company;

class A{
    public int a;

    public int harry(){
        return 4;
    }

    public void meh2(){
        System.out.println("HELLO");
    }
}

class B extends A{

    @Override
    public void meh2(){
        System.out.println("Hi");
    }

    public void meh3(){
        System.out.println("ij");
    }

}

public class metodoverriding {
    public static void main(String[] args) {
         A a = new A();
         a.meh2();
        B b =new B();
        b.meh2();


    }
}
