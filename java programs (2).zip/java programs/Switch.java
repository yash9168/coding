package com.company;

import java.util.Scanner;

public class Switch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER THE DAY IN NO");
        int day = sc.nextInt();
        switch (day){
            case 1:
                System.out.println("MONDAy");
                break;
            case 2:
                      System.out.println("TUES");
                      break;
            case 3:
                System.out.println("WeD");
                break;
            case 4:
                System.out.println("THURS");
                break;
            case 5:
                System.out.println("FRI");
                break;
            case 6:
                System.out.println("SAT");
                break;
            case 7:
                System.out.println("Sun");
                break;
        }
    }
}
