package com.company;

public class practicesetloop {
    public static void main(String[] args) {


//                int n=4;
//                for (int i =n ; i>0 ; i-- ){
//                            for (int j = 0 ; j<i ; j++) {
//                                System.out.print("*");
//                       }
//                    System.out.print("\n");
//        }

//           int n = 0 ;
//           while ( n<=20){
//               System.out.println(n);
//               n++;
//           }


                int n = 5;
//        for(int i=0; i<10; i++) - Goes from i=0 to i=9

        for(int i=1;i<=10;i++){

           System.out.printf("%d X %d = %d\n", n, i, n*i);
        }





    }
}
