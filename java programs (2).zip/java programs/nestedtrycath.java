package com.company;

public class nestedtrycath {
    public static void main(String[] args) {
            try {
                try {

                }catch (Exception e){
                    System.out.println();
                }
            }catch (Exception e){
                System.out.println();
            }
    }
}
