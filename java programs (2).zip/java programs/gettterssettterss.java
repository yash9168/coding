package com.company;

public class gettterssettterss {

    static class Employee{

        private int id;
        private String name;


        public String getName(){

            return name;
        }

        public void setName(String n ){
          name = n;
        }


        public int getId(){

            return id;
        }

        public void setId(int  i ){
             id  = i;
        }




    }


    public static void main(String[] args) {

        Employee yash = new Employee();

        yash.setId(3);
        yash.setName("aYUVATd");

        System.out.println(yash.getId());
        System.out.println(yash.getName());

    }
}
