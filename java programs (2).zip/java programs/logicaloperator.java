package com.company;

public class logicaloperator {
    public static void main(String[] args) {
        boolean a = true;
        boolean b = false;
        if (a || b){
            System.out.println("Y");
        }
        else {
            System.out.println("N");
        }
    }
}
