package com.company;

//abstract  class Pen{
//    abstract void write();
//    abstract void refill();
//}
//
//class fountainpen extends Pen{
//    void write(){
//        System.out.println("write");
//    }
//    void refill(){
//        System.out.println("REFILL");
//    }
//    void nib(){
//        System.out.println("change nib");
//    }
//
//}
class Monket {
    void jump(){
        System.out.println("jumping");
    }
    void bite(){
        System.out.println("biting");
    }}
    interface BASCICANIMAL{
        void eat();
        void sleep();
    }



  class Human extends Monket implements BASCICANIMAL{
        void speak(){
            System.out.println("hello ");
        }

        @Override
        public void eat() {
            System.out.println("EATI NG PANNER");
        }

        @Override
        public void sleep() {
            System.out.println("go to pee before sleep");
        }
    }



public class practicesetanstractinhertot {
    public static void main(String[] args) {
//        fountainpen pen = new fountainpen();
//        pen.nib();
//        pen.refill();
//        pen.write();

Human yash = new Human();
yash.eat();
yash.jump();

Monket m = new Human();
m.bite();
m.jump();
    }
}
