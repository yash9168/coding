package com.company;

import java.util.Scanner;

public class CalculatePercentage {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("PLEASE ENTER MARKS");
        int a ;
        a= sc.nextInt();
        System.out.println("MARKS SCORED IN MATHS IS " + a);
        int b ;
        b= sc.nextInt();
        System.out.println("MARKS SCORED IN EMGLISH IS " + b);
        int c ;
        c= sc.nextInt();
        System.out.println("MARKS SCORED IN PHYSICS" + c);
        int d ;
        d= sc.nextInt();
        System.out.println("MARKS SCORED IN PE IS " + d);
        int e ;
        e= sc.nextInt();
        System.out.println("MARKS SCORED IN CHEM IS " + e);
        double percentage;
        percentage = (a+b+c+d+e)*100/500d;
        System.out.println("YOUR PERCENTAGE IS " + percentage);
    }
}
