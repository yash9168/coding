package com.company;

import java.util.Scanner;

public class elseif {
    public static void main(String[] args) {
        System.out.println("ENTER UR AGE");
        Scanner sc = new Scanner(System.in);
        int age = sc.nextInt();
        if (age>60)
        {
            System.out.println("U R SENIOR");
        }
        else if(age>50){
            System.out.println("YOU ARE ADULT");
        }
        else{
            System.out.println("you are adult");
        }
    }
}
