package com.company;

class Mythreadrunnable implements Runnable{
    public void run(){
        System.out.println("im trhread notn threat");
    }
}
class Mythreadrunnable2 implements Runnable{
    public void run(){
        System.out.println("im trhread2 notn threat");
    }
}


public class runnableinterfacemulti {
    public static void main(String[] args) {
        Mythreadrunnable m1 = new Mythreadrunnable();
        Thread t1 = new Thread(m1);

        
        Mythreadrunnable2 m2 = new Mythreadrunnable2();
        Thread t2 = new Thread(m2);

        t1.start();
        t2.start();

    }
}
