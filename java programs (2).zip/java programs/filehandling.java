package com.company;


import java.util.Scanner;

public class filehandling {
    public static void main(String[] args) {
        int [] marks = new int[3];
        marks[0]= 7;
        marks[1]= 8;
        marks[2]= 9;
        Scanner sc  =new Scanner(System.in);
        int ind = sc.nextInt();
        int no = sc.nextInt();
        try {
            System.out.println(marks[ind ] / no);

}
        catch (Exception e){
            System.out.println("error");
     }}}

