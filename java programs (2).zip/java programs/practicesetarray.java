package com.company;

public class practicesetarray {
    public static void main(String[] args) {
//        float [] marks= {2.5f,3.4f,3.5f,6.2f};
//        float sum = 0;
//        for (float element : marks)
//        {
//            sum = sum + element;
//
//
//        }
//
//        System.out.println( sum);

        float [] marks= {2.5f,3.4f,3.5f,6.2f};
        float num  = 3.4f;
            boolean IsInArray  = false;
            for (float element: marks){
                if (num == element){
                    IsInArray = true;
                    break;
                }
            }
            if (IsInArray){
                System.out.println("present");
            }
            else {
                System.out.println("not present");
            }

    }
}
