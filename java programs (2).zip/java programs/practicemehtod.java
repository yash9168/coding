package com.company;

public class practicemehtod {
//
//    static void  logic(int x)
//    {
//        for (int i=1 ; i<=10 ; i++)
//        {
//            System.out.format("%d X %d = %d\n", x ,i ,x*i);
//        }
//
//    }
//

//    static  int sum(int n){
//
//        if (n==1){
//            return 1;
//        }
//
//            return n + sum(n-1);
//
//
//
//    }

    static  int fib(int a){
        if (a==1){
            return 0;
        }

        else if (a==2){
            return 1;

        }
        else {
            return fib(a-1) + fib(a-2);

        }    }

    public static void main(String[] args) {



//            logic(2);
//            int c =sum(4);
//        System.out.println(c);

     int result =   fib(5);
        System.out.println(result);
    }
}
