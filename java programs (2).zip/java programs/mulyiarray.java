package com.company;

import javax.management.MBeanAttributeInfo;

public class mulyiarray {
    public static void main(String[] args) {
        int [] []  flats= new int[2][3] ;
        flats [0][0]= 101;
        flats [0][1]= 101;
        flats [0][2]= 101;
        flats [1][0]= 101;
        flats [1][1]= 101;
        flats [1][2]= 101;


        for (int i =0  ; i< flats.length; i++ )
        {
            for (int j =0 ; j<flats[i].length; j++)
                System.out.print(flats[i][j]);
            System.out.println(" ");


        }
        System.out.println("");
    }
}
