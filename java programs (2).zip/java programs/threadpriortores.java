package com.company;


class mythr extends Thread{
    public  mythr (String Name){
        super(Name);
    }
    public void run(){
        int i =3;
        System.out.println("hello" + this.getName());
    }
}

public class threadpriortores {
    public static void main(String[] args) {

        mythr m1 = new mythr("yash1 ");
        mythr m2 = new mythr("yash2");
        mythr m3 = new mythr("yash3");
        mythr m4 = new mythr("yash4");
        m1.start();
        m2.setPriority(Thread.MIN_PRIORITY);
        m2.start();
        m3.start();
        m4.start();
    }
}
