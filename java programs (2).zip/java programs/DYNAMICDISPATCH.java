package com.company;

class Phone{

    public void greet(){
        System.out.println("GOOD MORNING");
    }


    public void on(){
        System.out.println("turning on nokia");
    }
}

class Smartphone extends Phone{
    public void swagat(){
        System.out.println("SWAGAT krtehai paka");
    }

    @Override
    public void on(){
        System.out.println("turning on oppo f11");
    }
}



public class DYNAMICDISPATCH {
    public static void main(String[] args) {
        Phone obj = new Smartphone();
        obj.greet();
        obj.on();

    }
}
