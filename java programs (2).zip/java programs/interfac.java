package com.company;

interface  Bycycle{
    int a = 31;



    void applybrake(  int decrement);


    void speedup( int increment);



}

class Avoncycle implements Bycycle{

    void blowhorn(){
        System.out.println("PEPEPEPE");

    }

    public  void applybrake(int decrement){
        System.out.println("SPEED DECREASE");
    }

    public  void speedup(int incrrement){
        System.out.println("SPEED UP");
    }

}



public class interfac {
    public static void main(String[] args) {

        Avoncycle a = new Avoncycle();
        a.applybrake(34);

    }
}
