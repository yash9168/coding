package com.company;


abstract class BAse{
    public BAse(){
        System.out.println("I M  CONSTRUCTOE OF BASE 2");
    }

    public void sayhello(){
        System.out.println("HELLO");
    }

    abstract public  void greet();


}


class BASE2 extends BAse{
    @Override
    public  void greet(){
        System.out.println("GOOD MORNING");
    }
}

public class Abstarsct {
    public static void main(String[] args) {
        BASE2 b = new BASE2();

       b.greet();
    }
}
