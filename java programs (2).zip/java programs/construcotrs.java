package com.company;


import javax.naming.Name;

class MyEmployee
{
    private  int Id;
    private String n;

//    public  MyEmployee() {
//        Id = 90;
//        n = "uvv";
//    }


    public  MyEmployee(String myname) {
        Id = 90;
        n = myname;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getN() {
        return n;
    }

    public void setN(String n) {
        this.n = n;
    }



}






public class construcotrs {


    public static void main(String[] args) {

    MyEmployee yash =  new MyEmployee("fsdgds");
//    yash.setId(32);
//    yash.setN("YUVI SHAH");

        System.out.println(yash.getId());
        System.out.println(yash.getN());

    }
}
