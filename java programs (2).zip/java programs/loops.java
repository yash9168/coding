package com.company;

public class loops {
    public static void main(String[] args) {
//
//        int i = 0;
//        while (i<=4){
//            System.out.println(i);
//            i++;


                    int n=100;
                    while (n<=200)
                    {
                        System.out.println(n);
                        n++;
        }
    }
}
