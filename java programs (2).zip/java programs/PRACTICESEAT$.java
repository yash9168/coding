package com.company;

import java.util.Scanner;

public class PRACTICESEAT$ {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
//        System.out.println("ENTER UR MARKS");
//        float marks1 = sc.nextInt();
//        float marks2 = sc.nextInt();
//        float marks3 = sc.nextInt();
//        float total = (marks1+marks2+marks3)*100f/300f;
//                if (total >= 40.0 &&  marks1 >=33 && marks2>=33  && marks3>=33) {
//                    System.out.println("CONGRATS");
//                }
//                else {
//                    System.out.println("WORK HARD");

//                }

//        System.out.println("ENTER UR INCOME");
//        float income = sc.nextFloat();
//
//        if (income>2.5f && income<5.0f)
//
//        {
//            float tax =5;
//                    System.out.println(tax);
//        }
//                else {
//
//                        float tax  = 10;
//            System.out.println(tax
//            );
//
//    }

        String website = sc.next();
        if (website.endsWith(".com" ))
        {
            System.out.println("its commercial website");
        }

}}
