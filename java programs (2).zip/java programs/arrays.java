package com.company;

public class arrays {
    public static void main(String[] args) {
        int [] marks = {2,4,5,6};
        System.out.println(marks[1]);
    }
}
