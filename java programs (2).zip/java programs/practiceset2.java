package com.company;

import java.util.Scanner;

public class practiceset2 {
    public static void main(String[] args) {
//        float a = 7/4f*9/2f;
//        System.out.println(a);
//    }
//
//        char grade = 'A';
//        grade = (char) (grade+ 8);
//        System.out.println(grade);


        Scanner sc = new Scanner(System.in);
        System.out.println("ENTER UR no");
        int a = sc.nextInt();
        System.out.println(a>3);


    }
}
