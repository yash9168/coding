package com.company;

//class Circle{
//    public  int r;
//
//    public int getR() {
//        return r;
//    }
//
//    public void setR(int r) {
//        this.r = r;
//    }
//    public
//}
//
//
//class Cylinde extends Circle{
//    public int h;
//
//    public int getH() {
//        return h;
//    }
//
//    public void setH(int h) {
//        this.h = h;
//    }
//
//    public double Area(){
//
//        return  3.14*r*r*h;
//    }
//
//}



class Rectanglee{

    public int lenght;
    public int breadth;

    Rectanglee(int l , int b){

        this.lenght = l;
        this.breadth = b;
    }


    public int Area(){
        return this.breadth*this.lenght;
    }

}


class Cuboid extends Rectanglee{

    public int height;
    Cuboid(int l , int b , int h){
        super(l,b);
        this.height = h;


    }

    public int volume(){
        return this.height*this.lenght*this.breadth;
    }

}





public class preacticesetinherittene {





    public static void main(String[] args) {



            Cuboid c = new Cuboid(4,5,6);
        System.out.println(c.volume());
        System.out.println(c.Area());

    }
}
