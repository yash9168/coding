package com.company;



//class Employe {
//
//    int salary;
//    String name;
//
//    public int getSalary(){
//        return salary;
//    }
//
//    public String getName(){
//        return name;
//    }
//
//    public void setName(String n){
//        name=n;
//    }
//
//}

//
//        class cellphone{
//            public  void ringing(){
//                System.out.println("RINGING....");
//
//            }
//            public  void vibrating(){
//                System.out.println("VIBRATING...");
//            }
//        }



//            class Square{
//
//                public int Area(int a){
//                    return a*a;
//                }
//
//                public int Perimeter(int a){
//                    return 4*a;
//                }
//            }
//


            class Rectangle{
                public int ar0ea(int x , int y ){
                    return x*y;
                }

                public int perimeter(int x , int y){
                    return 2*x + 2*y;
                }
            }


public class practicesetoops {


    public static void main(String[] args) {

//            Employe yash = new Employe();
//            yash.setName("yuvi");
//            yash.getName();
//            yash.salary = 32;
//            yash.getSalary();
//        System.out.println(yash.getName());
//        System.out.println(yash.getSalary());
//
//                cellphone nokia = new cellphone();
//                nokia.ringing();
//                nokia.vibrating();

//
//        Square s = new Square();
//        System.out.println(s.Area(4));
//        System.out.println(s.Perimeter(4));


Rectangle shape = new Rectangle();
        System.out.println(shape.ar0ea(3,2));
        System.out.println(shape.perimeter(3,2));


    }
}
