package com.company;

public class mehtodoverloading2 {

     static void foo()
     {
         System.out.println("I LUV U");
     }

     static void foo(int a){
         System.out.println("I LUV  U " + a);
     }

    public static void main(String[] args) {
        foo();
        foo(3000
        );
    }
}
