package com.company;
import java.util.Scanner;
public class UserInput {
    public static void main(String[] args) {
     Scanner sc  = new Scanner(System.in);
        System.out.println("PLEASE INSERT NUMBERS");
//        int a  = sc.nextInt();
//        System.out.println("you enterde " + a);
//        int b= sc.nextInt();
//        System.out.println("you enterde " + b);
//        int sum = a+b;
//        System.out.println("sum is" + sum);
                boolean a = sc.hasNextInt();
        System.out.println(a);

    }
}
