package com.company;

import java.util.Scanner;

public class queuearray {
    int f=-1 , r=-1;
    int n=10;
    int q[] =new int[n];
    Scanner sc = new Scanner(System.in);

    void enqueue(Scanner sc){
        if (r==(n-1))
        {
            System.out.println("overflow");
        }

        else {
            System.out.println("enter data");
            int i = sc.nextInt();
            if (f==-1 && r==-1)
            {
                f=0;
                r=0;
                q[r]=i;
            }
            else {
                r=r+1;
                q[r]=i;

            }
        }

    }

    void dequeue(){
        if (f==-1&& r==-1)
        {
            System.out.println("underflow");
        }
        else {
            f=f+1;

        }

    }
    void display ()
    {
        System.out.println("ITems are");
        for (int i =f ; i<=r ; i++)
        {
            System.out.println(q[i]);
        }

    }
}

 class queue_array {
    public static void main(String[] args) {
        queuearray s = new queuearray();
        Scanner sc = new Scanner(System.in);
        int l;
        do {


            System.out.println("press 1 to  enqueue");
            System.out.println("press 2 to dequeue");
            System.out.println("press 3 to display");
            System.out.println("Enter your choice");
            int d = sc.nextInt();
            switch (d) {
                case 1: {
                    s.enqueue(sc);
                    break;
                }
                case 2: {
                    s.dequeue();
                    break;
                }
                case 3: {
                    s.display();
                    break;
                }
            }
            System.out.println("Enter 0 to go back");
            System.out.println("enter any key to exit");
            l = sc.nextInt();

        }while (l==0);
        System.out.println("Exit Sucessfully");
    }
}
