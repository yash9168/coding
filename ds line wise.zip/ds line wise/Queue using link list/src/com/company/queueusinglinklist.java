package com.company;

import java.util.Scanner;

public class queueusinglinklist {

    static  class Node {
        int data;
        Node next;



        Node(int data) {
            this.data = data;
            this.next = null;
        }}
    Node f= null;
    Node r= null;

    void enqueue(Scanner sc){
        System.out.println("Enter the Data");
        int data = sc.nextInt();
        Node new_node = new Node(data);
        if (f==null)
        {
            f=new_node;
            r=new_node;
        }else{
            r.next = new_node;
            r=new_node;
        }

    }
    void dequeue(){
        if (f==null)
        {
            System.out.println("Underflow");
        }
        else{
            f=f.next;
        }

    }
    void display(){
                Node temp = f;
                while (temp!=null)
                {
                    System.out.println(temp.data);
                    temp=temp.next;
                }

    }
}










class queue_ll {
    public static void main(String[] args) {
        queueusinglinklist s= new queueusinglinklist();
        Scanner sc = new Scanner(System.in);
        int l;
        do {


            System.out.println("press 1 to enqueue");
            System.out.println("press 2 to dequeue");
            System.out.println("press 3 to display");
            System.out.println("enter choice");
            int d = sc.nextInt();
            switch (d) {
                case 1: {
                    s.enqueue(sc);
                    break;
                }
                case 2: {
                    s.dequeue();
                    break;
                }
                case 3: {
                    s.display();
                    break;
                }
            }
            System.out.println("Enter 0 to go back");
            System.out.println("enter any key to exit");
            l = sc.nextInt();

        }while (l==0);
        System.out.println("Exit Sucessfully");
    }
}
