package com.company;

import java.util.Scanner;

 class queue {
    int f=-1 , r=-1;
    int n=10;
    int q[] =new int[n];
    Scanner sc = new Scanner(System.in);

    void enqueue(Scanner sc){
        if (f==(r+1)%n)
        {
            System.out.println("overflow");
        }

        else {
            System.out.println("enter data");
            int i = sc.nextInt();
            if (f==-1 && r==-1)
            {
                f=0;
                r=0;
                q[r]=i;
            }
            else {
                r=(r+1)%n;
                q[r]=i;

            }
        }

    }

    void dequeue(){
        if (f==-1&& r==-1)
        {
            System.out.println("underflow");
        }
        else if (f==r)
        {
            System.out.println("Underflow");
            f=-1;
            r=-1;
        }
        else {
            f=(f+1)%n;

        }

    }
    void display ()
    {int i;
        System.out.println("ITems are");
       for ( i = f ; i!=r ; i=(i+1)%n)
       {
           System.out.println(q[i]);
       }
        System.out.println(q[i]);

    }
}

class Circular_Queue {
    public static void main(String[] args) {
        queue s = new queue();
        Scanner sc = new Scanner(System.in);
        int l;
        do {


            System.out.println("press 1 to  enqueue");
            System.out.println("press 2 to dequeue");
            System.out.println("press 3 to display");
            System.out.println("Enter your choice");
            int d = sc.nextInt();
            switch (d) {
                case 1: {
                    s.enqueue(sc);
                    break;
                }
                case 2: {
                    s.dequeue();
                    break;
                }
                case 3: {
                    s.display();
                    break;
                }
            }
            System.out.println("Enter 0 to go back");
            System.out.println("enter any key to exit");
            l = sc.nextInt();

        }while (l==0);
        System.out.println("Exit Sucessfully");
    }
}
