package com.company;

import java.util.Scanner;

class stackladl{

    static  class Node {
        int data;
        Node next;


        Node(int data) {
            this.data = data;
            this.next = null;
        }}
    Node top= null;

    void push(){
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter data");
        int data = sc.nextInt();
        Node new_node= new Node(data);
        if (top==null){
            top =new_node;
        }
        else {
            new_node.next=top;
            top=new_node;
        }
    }
    void pop(){
        if (top==null)
        {
            System.out.println("stacl is empty");
        }
        else
        {
            top = top.next;

        }
    }
    void display(){
        Node temp =top;
        while (temp!=null)
        {
            System.out.println(temp.data);
            temp=temp.next;
        }

    }
}










class stack_ll {
    public static void main(String[] args) {
        stackladl s= new stackladl();
        Scanner sc = new Scanner(System.in);
        int l;
        do {


            System.out.println("press 1 to push");
            System.out.println("press 2 to pop");
            System.out.println("press 3 to display");
            int d = sc.nextInt();
            switch (d) {
                case 1: {
                    s.push();
                    break;
                }
                case 2: {
                    s.pop();
                    break;
                }
                case 3: {
                    s.display();
                    break;
                }
            }
            System.out.println("Enter 0 to go back");
            System.out.println("enter any key to exit");
            l = sc.nextInt();

        }while (l==0);
        System.out.println("Exit Sucessfully");
    }

}
