import java.util.Scanner;

class  stack
{
    int top= -1;
    int n=10;
    int a[] =new int[n];
    Scanner sc = new Scanner(System.in);

    void push(){
        if (top==(n-1))
        {
            System.out.println("Overflow");
        }
        else {
            System.out.println("Enter data");
            int i = sc.nextInt();
            top = top+1;
            a[top] = i;
            System.out.println("Item Inserted");

        }
    }

    void pop(){
            if (top==-1)
            {
                System.out.println("Underflow");
            }
            else {
                top = top-1;
                System.out.println("item deleted");
            }
    }
    void display ()
    {
        System.out.println("ITems are");
        for (int j=top ; j>=0 ; j--)
        {
            System.out.println(a[j]);
        }
    }
}

public class stack_array {
    public static void main(String[] args) {
        stack s = new stack();
        Scanner sc = new Scanner(System.in);
        int l;
        do {


            System.out.println("press 1 to push");
            System.out.println("press 2 to pop");
            System.out.println("press 3 to display");
            int d = sc.nextInt();
            switch (d) {
                case 1: {
                    s.push();
                    break;
                }
                case 2: {
                    s.pop();
                    break;
                }
                case 3: {
                    s.display();
                    break;
                }
            }
            System.out.println("Enter 0 to go back");
            System.out.println("enter any key to exit");
            l = sc.nextInt();

        }while (l==0);
        System.out.println("Exit Sucessfully");
    }

}
