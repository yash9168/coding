import java.util.Scanner;

public class circularlinklistcraetion {


        static  class Node{
            int data;
            Node next;
            Node(int data){
                this.data=data;
                this.next=null;
            }
        }
        Node head =null;


        public void creation ()
        {

            int data , n;
            Scanner sc = new Scanner(System.in);

            do {
                System.out.println("ENTER DATA");
                data= sc.nextInt();
                Node new_node = new Node(data);
                if (head==null){

                    head=new_node;


                }
                else
                {
                    // single creation
                    //                new_node.next =head;
                    //                head=new_node;



                    // insertionofnode
                    System.out.println("Press 1 to insert at begining , press 2 to insert at end , press 3 to insert at partciular location");
                    int m = sc.nextInt();
                    switch (m){
                        case 1:

                            new_node.next=head;
                            head = new_node;

                            break;
                        case 2:
                            Node temp=head;
                            while (temp.next!=null)
                            {
                                temp =temp.next;

                            }
                            temp.next =head;

                            break;

                        case 3:
                            System.out.println("enter the posotion of the node");
                            int p = sc.nextInt();
                            Node temp1 =head;
                            for (int i=0 ; i<(p-1) ; i++){
                                temp1=temp1.next;

                            }
                            new_node.next=temp1.next;
                            temp1.next=new_node;

                            break;


                    }

                }

                System.out.println("do you want to add more data press 1");
                n=sc.nextInt();

            }while (n==1);

        }

        public void traverser ()
        {

            Node temp = head;
            if (head==null){
                System.out.println("link list does not exist");
            }
            else {


                while (temp!=null){
                    System.out.print(temp.data + "->");
                    temp=temp.next;
                }





            }





        }
        // for circular
        public void delete ()
        {

            int data,n,m,p;
            Scanner sc =  new Scanner(System.in);
            do {
                if (head==null){
                    System.out.println("LL is empty");
                }
                else {
                    System.out.println("EMter 1 to delete node at starting , enter 2 to delete at end , enter 3 to delte at postion");
                    m= sc.nextInt();

                    switch (m)
                    {
                        case 1:
                            Node temp= head;
                            temp=temp.next;
                            head=temp;



                            break;

                        case 2:
                            Node temp3= head;
                            Node ptr =temp3.next;
                            while (ptr.next!=null)
                            {
                                temp3 = ptr;
                                ptr =ptr.next;

                            }

                            temp3.next=null;

                            break;
                        case 3:
                            System.out.println("enter the position of deleteing");
                            p= sc.nextInt();
                            Node temp4=head;
                            Node ptr1 = temp4.next;
                            for (int i=0 ; i<(p-2) ; i++)
                            {
                                temp4=ptr1;
                                ptr1=ptr1.next;

                            }
                            temp4.next =ptr1.next;

                            break;

                    }



                }
                System.out.println("do wou want to delete more data press 1");
                n= sc.nextInt();
            }

            while (n==1);

        }
        public static void main(String[] args) {

            circularlinklistcraetion ll = null;
            ll.creation();
            ll.traverser();




        }

    }


