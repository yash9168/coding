package com.company.main;

import java.util.Scanner;

public class twodarray {
    public static void main(String[] args) {
        int n,m,p;

        Scanner sc = new Scanner(System.in);

        System.out.println("enter the no of rows");
        n=sc.nextInt();

        System.out.println("enter no of columns");
        m=sc.nextInt();
        int a[][] =new int[n][m];

        System.out.println("Enter values");

        for (int i=0 ; i<n ; i++)
        {
            for (int j=0 ; j<m ; j++)
            {
                a[i][j]=sc.nextInt();

            }
        }

        for (int i=0 ; i<n ; i++)
        {
            for (int j=0 ; j<m ; j++)
            {
                System.out.print(a[i][j]+ " ");

            }
            System.out.println();
        }


    }
}
