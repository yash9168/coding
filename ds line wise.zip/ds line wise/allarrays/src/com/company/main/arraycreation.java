package com.company.main;

import java.util.Scanner;

 class arrayCreation {
    public static void main(String[] args) {
        int n;
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the nos for araay");
        n =sc.nextInt();
        int a [] = new int[n];
        System.out.println("Enter your values");
        for (int i =0 ; i<n ; i++){
            a[i] =sc.nextInt();

        }
        System.out.println("elements are ");
        for (int i = 0 ; i<n ; i++){
            System.out.print(a[i]);
        }

    }
}
