package com.company.main;

import java.util.Scanner;

public class deletionofarray {
    public static void main(String[] args) {
        int n;
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the nos for araay");
        n =sc.nextInt();
        int a [] = new int[n];
        int b [] =new int[n-1];
        System.out.println("Enter your values");
        for (int i =0 ; i<n ; i++){
            a[i] =sc.nextInt();

        }

        System.out.println("enter the index value you want to remove");
        int m = sc.nextInt();

        for (int i =0 ; i<a.length ;i++){
            if (i<m){
                b[i] =a[i];
            }
            else if (i==m){
                continue;
            }
            else {
            b[i-1] = a[i];
            }

            }
        for (int i =0 ; i<n-1 ; i++){
            System.out.println(b[i]);

        }
        }
    }

