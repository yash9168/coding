package com.company.main;

import java.util.Scanner;

public class insertingarray {
    public static void main(String[] args) {
        int n;
        Scanner sc = new Scanner(System.in);
        System.out.println("enter the nos for araay");
        n =sc.nextInt();
        int a [] = new int[n];
        int b [] =new int[n+1];
        System.out.println("Enter your values");
        for (int i =0 ; i<n ; i++){
            a[i] =sc.nextInt();

        }

        System.out.println("enter the index of new value");
        int m = sc.nextInt();

        System.out.println("enter the new value");
        int p = sc.nextInt();

        for (int i =0 ; i<n+1 ; i++){
            if (i<m){
                b[i] = a[i];
            }
            else if (i==m){
                b[i]=p;

            }
            else {
                b[i] = a[i-1];
            }

        }



        System.out.println("elements are ");
        for (int i = 0 ; i<n+1 ; i++){
            System.out.print(b[i]);
        }

    }
}
