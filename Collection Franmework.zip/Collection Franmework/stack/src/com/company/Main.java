package com.company;

import java.util.Scanner;
import java.util.Stack;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Stack<Integer> c = new Stack<>();
//        c.push(100);
//        c.push(200);
//        c.push(300);
//        c.push(400);
////        System.out.println(c);
//
////        int d= c.peek();
////        System.out.println(d);
//
////         c.pop();
//        int s = c.search(300);
////        System.out.println(c);
//        System.out.println(s);



        for (int i =0 ; i<5 ; i++)
        {
            System.out.println("enter values");
            int value = sc.nextInt();
            c.push(value);
        }
        System.out.println(c);

        if (!c.isEmpty())
        {
            c.pop();
        }
    }

}
