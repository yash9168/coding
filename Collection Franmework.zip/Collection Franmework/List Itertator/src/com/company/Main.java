package com.company;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class Main {

    public static void main(String[] args) {
        List<Integer> c= new ArrayList<>();
        c.add(null);
        c.add(10);
        c.add(20);
        c.add(30);
//        c.set(2 , 150);
//        boolean f = c.contains(30);
////	c.remove(2);
////		int d = c.get(3);
////        System.out.println(c);
////		System.out.println(d);
////		c.clear();
////		System.out.println(c);
////		System.out.println(f);
//        for (int i =0 ; i<c.size(); i++)
//        {
//            System.out.println(c.get(i));
//        }

        ListIterator<Integer> a = c.listIterator()
                ;

        while (a.hasNext())
        {
            System.out.println(a.next());
        }
        while (a.hasPrevious())
        {
            System.out.println(a.previous());
        }
    }
}
