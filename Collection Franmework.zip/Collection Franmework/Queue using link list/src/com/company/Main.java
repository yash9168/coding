package com.company;

import java.util.LinkedList;
import java.util.Queue;

public class Main {

    public static void main(String[] args) {
        Queue<Integer> s = new LinkedList<>();
        s.offer(10);
        s.offer(20);
        s.offer(30);
        s.offer(40);
//        System.out.println(s);
//        System.out.println(s.peek());

        s.poll();
        System.out.println(s);

    }
}
