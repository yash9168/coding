package com.company;

import java.util.LinkedList;

public class Main {

    public static void main(String[] args) {

        LinkedList<Integer> n =new LinkedList<>();
        n.add(10);
        n.add(20);
        n.add(30);
        n.add(40);
        n.add(50);
//        System.out.println(n);
//       int c=  n.get(2);
        int c = n.set(1 , 90);
        n.clear();
        System.out.println(n);
    }
}
