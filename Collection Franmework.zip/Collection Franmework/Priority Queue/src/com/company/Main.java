package com.company;

import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

public class Main {

    public static void main(String[] args) {

//        Queue<Integer> n = new PriorityQueue<>();
//        use for min order
         Queue<Integer> n = new PriorityQueue<>(Comparator.reverseOrder());
//         use for max order
        n.offer(10);
        n.offer(20);
        n.offer(5);
        n.offer(30);
        n.offer(40);
        n.poll();
        System.out.println(n);

    }
}
