package com.company;

import java.util.HashMap;
import java.util.Map;

public class Main {

    public static void main(String[] args) {

        Map<Integer , String> s = new HashMap<>();
        s.put(1 , "y");
        s.put(2 , "A");
        s.put(3 , "S");
        s.putIfAbsent(7 , "H");
//        s.remove(2);
////        System.out.println(s.isEmpty());
//        System.out.println(s);
        for (Integer d:s.keySet())
        {
            System.out.println(d);
        }
    }
}
