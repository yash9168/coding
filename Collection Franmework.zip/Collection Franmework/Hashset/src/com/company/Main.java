package com.company;

import java.util.HashSet;
import java.util.Set;

public class Main {

    public static void main(String[] args) {

        Set<Integer> s =new HashSet<>();
        s.add(10);
        s.add(20);
        s.add(30);
        s.add(40);
        s.add(50);
        s.remove(20);
//        s.clear();
      int a =   s.size();
        System.out.println(s);
        System.out.println(a);
    }
}
