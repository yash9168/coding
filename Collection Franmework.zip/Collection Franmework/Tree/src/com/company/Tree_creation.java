package com.company;


import org.w3c.dom.Node;

import java.util.Scanner;

class Tree_creation {

    static Node create()
    {
        int data;
        Scanner sc = new Scanner(System.in);
        Node root =null;
        System.out.println("Enter the data");
        data = sc.nextInt();
        if (data==-1)

            return null;
            root = new Node(data);
            System.out.println("enter left child of " + root.data);
            root.left=create();
            System.out.println("enter right child of " + root.data);
            root.right=create();
            return root;

    }

    static void inorder(Node root)
    {
        if (root==null)
            return;

        inorder(root.left);
        System.out.println(root.data);
        inorder(root.right);
    }

    static void preorder(Node root)
    {
        if (root==null)
            return;


        System.out.println(root.data);
        preorder(root.left);
        preorder(root.right);
    }

    static void  postorder(Node root)
    {
        if (root==null)
            return;

        preorder(root.left);

        postorder(root.right);

        System.out.println(root.data);
    }


    public static void main(String[] args) {



        Node root = create();
        inorder(root);
        System.out.println();
        postorder(root);
        System.out.println();
        preorder(root);
        System.out.println();



    }


   static   class Node{
        Node left , right;
        int data;
        public Node(int data)
        {
            this.data = data;
            left = null;
            right=null;
        }
    }




}
