package com.company;

import java.util.Set;
import java.util.TreeSet;

public class Main {

    public static void main(String[] args) {

        Set<Integer> n = new TreeSet<>();
        n.add(10);
        n.add(20);
        n.add(50);
        n.add(40);
        n.add(30);
        System.out.println(n);
    }
}
