package com.company;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class Main {

    public static void main(String[] args) {

        Map<Integer , String> s = new TreeMap<>();

        s.put(3 , "S");
        s.put(1 , "y");
        s.put(2 , "A");
        s.putIfAbsent(7 , "H");
//        s.remove(2);
////        System.out.println(s.isEmpty());
//        System.out.println(s);
        for (Integer d:s.keySet())
        {
            System.out.println(d);
        }
    }
}
